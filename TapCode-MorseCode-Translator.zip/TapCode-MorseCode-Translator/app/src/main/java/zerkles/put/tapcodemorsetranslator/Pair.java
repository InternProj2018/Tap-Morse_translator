package zerkles.put.tapcodemorsetranslator;

public class Pair<T1, T2> {
    private T1 key;
    private T2 value;

    Pair(T1 key, T2 value) {
        this.key = key;
        this.value = value;
    }

    T1 getKey() {
        return key;
    }

    void setKey(T1 new_key) {
        key = new_key;
    }

    T2 getValue() {
        return value;
    }

    void setValue(T2 new_value) {
        value = new_value;
    }


}
