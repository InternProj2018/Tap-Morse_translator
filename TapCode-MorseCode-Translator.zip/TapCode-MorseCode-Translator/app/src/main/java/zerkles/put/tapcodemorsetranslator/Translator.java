package zerkles.put.tapcodemorsetranslator;

import android.util.Log;

import java.util.HashMap;
import java.util.Map;

public class Translator {

    static Map<Character, String> tapcode_schema;
    static Map<Character, String> morse_schema;

    Translator() {
        init_schemas();
    }

    private void init_schemas() {
        /// source: https://en.wikipedia.org/wiki/Tap_code
        /// / means next word; ' ' means next character; + means same character (in tapcode);
        tapcode_schema = new HashMap<Character, String>();
        tapcode_schema.put('A', "*+*");
        tapcode_schema.put('B', "*+**");
        tapcode_schema.put('C', "*+***");
        tapcode_schema.put('K', "*+***");
        tapcode_schema.put('D', "*+****");
        tapcode_schema.put('E', "*+*****");
        tapcode_schema.put('F', "**+*");
        tapcode_schema.put('G', "**+**");
        tapcode_schema.put('H', "**+***");
        tapcode_schema.put('I', "**+****");
        tapcode_schema.put('J', "**+*****");
        tapcode_schema.put('L', "***+*");
        tapcode_schema.put('M', "***+**");
        tapcode_schema.put('N', "***+***");
        tapcode_schema.put('O', "***+****");
        tapcode_schema.put('P', "***+*****");
        tapcode_schema.put('Q', "****+*");
        tapcode_schema.put('R', "****+**");
        tapcode_schema.put('S', "****+***");
        tapcode_schema.put('T', "****+****");
        tapcode_schema.put('U', "****+*****");
        tapcode_schema.put('V', "*****+*");
        tapcode_schema.put('W', "*****+**");
        tapcode_schema.put('X', "*****+***");
        tapcode_schema.put('Y', "*****+****");
        tapcode_schema.put('Z', "*****+*****");
        tapcode_schema.put(' ', "/");

        /// Adding lowercase keys
        Map<Character, String> temporary_map = new HashMap<>();
        for (Character c : tapcode_schema.keySet()) {
            temporary_map.put(c.toString().toLowerCase().charAt(0), tapcode_schema.get(c));
        }
        tapcode_schema.putAll(temporary_map);

        /// source: https://en.wikipedia.org/wiki/Morse_code
        /// used standard: ITU
        morse_schema = new HashMap<Character, String>();
        morse_schema.put(' ', "/");
        morse_schema.put('A', "*-");
        morse_schema.put('B', "-***");
        morse_schema.put('C', "-*-*");
        morse_schema.put('D', "-**");
        morse_schema.put('E', "*");
        morse_schema.put('F', "**-*");
        morse_schema.put('G', "--*");
        morse_schema.put('H', "****");
        morse_schema.put('I', "**");
        morse_schema.put('J', "*---");
        morse_schema.put('K', "-*-");
        morse_schema.put('L', "*-**");
        morse_schema.put('M', "--");
        morse_schema.put('N', "-*");
        morse_schema.put('O', "---");
        morse_schema.put('P', "*--*");
        morse_schema.put('Q', "--*-");
        morse_schema.put('R', "*-*");
        morse_schema.put('S', "***");
        morse_schema.put('T', "-");
        morse_schema.put('U', "**-");
        morse_schema.put('V', "***-");
        morse_schema.put('W', "*--");
        morse_schema.put('X', "-**-");
        morse_schema.put('Y', "-*--");
        morse_schema.put('Z', "--**");
        morse_schema.put('1', "*----");
        morse_schema.put('2', "**---");
        morse_schema.put('3', "***--");
        morse_schema.put('4', "****--");
        morse_schema.put('5', "*****");
        morse_schema.put('6', "-****");
        morse_schema.put('7', "--***");
        morse_schema.put('8', "---**");
        morse_schema.put('9', "----*");
        morse_schema.put('0', "-----");

        /// Adding lowercase keys
        temporary_map.clear();
        for (Character c : morse_schema.keySet()) {
            temporary_map.put(c.toString().toLowerCase().charAt(0), morse_schema.get(c));
        }
        morse_schema.putAll(temporary_map);
    }

    public String translate_letter_morse(Character c) {
        return morse_schema.get(c);
    }

    public String translate_letter_tapcode(Character c) {
        return tapcode_schema.get(c);
    }

    public static String translate_text_morse(String text) {
        String translation = "";

        for (Character c : text.toCharArray()) {
            translation += morse_schema.get(c);
            translation += ' ';
        }

        return translation;
    }

    public static String translate_text_tapcode(String text) {
        String translation = "";

        for (Character c : text.toCharArray()) {
            translation += tapcode_schema.get(c);
            translation += ' ';
        }

        return translation;
    }
}
///Rules used for timing of dots and dashes:
// The length of a dot is 1 time unit.
//
//A dash is 3 time units.
//
//The space between symbols (dots and dashes) of the same letter is 1 time unit.
//
//The space between letters is 3 time units.
//
//The space between words is 7 time units.