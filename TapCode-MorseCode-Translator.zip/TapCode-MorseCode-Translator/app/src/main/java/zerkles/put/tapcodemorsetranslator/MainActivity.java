package zerkles.put.tapcodemorsetranslator;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    Button btn_translate;
    CheckBox chb_flashlight, chb_sound;
    SeekBar sb_frequency;
    TextView tv_actual_letter, tv_actual_translation, tv_sb_speed;
    EditText et_input;
    Spinner spn_choose;

    int time_unit = 240; /// in ms
    LoopTask actual_LoopTask;
    FlashlightController flashlight_controller = new FlashlightController(this);
    Translator translator = new Translator();

    /// Bounding layout elements with logic
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chb_flashlight = findViewById(R.id.chb_flashlight);
        chb_sound = findViewById(R.id.chb_sound);

        tv_actual_letter = findViewById(R.id.tv_actual_letter);
        tv_actual_translation = findViewById(R.id.tv_actual_translation);
        tv_sb_speed = findViewById(R.id.tv_sb_speed);

        et_input = findViewById(R.id.et_input);
        spn_choose = findViewById(R.id.spn_choose);

        btn_translate = findViewById(R.id.btn_translate);
        btn_translate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (actual_LoopTask == null) {
                    actual_LoopTask = new LoopTask();
                    actual_LoopTask.execute();
                } else {
                    actual_LoopTask.cancel(true);
                    actual_LoopTask = new LoopTask();
                    actual_LoopTask.execute();
                }

            }
        });
        sb_frequency = findViewById(R.id.sb_frequency);
        sb_frequency.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                switch (progress) {
                    case 0:
                        time_unit = 60;
                        break;
                    case 1:
                        time_unit = 120;
                        break;
                    case 2:
                        time_unit = 240;
                        break;
                    case 3:
                        time_unit = 1200;
                        break;
                    default:
                        time_unit = 240;
                        break;
                }

                tv_sb_speed.setText("Speed: " + String.valueOf(time_unit) + "ms");
            }
        });

        String[] items = new String[]{"Morse Code", "Tap Code"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        spn_choose.setAdapter(adapter);

        check_flashlight_available();
    }


    /// Check if device has flashlight and if app has permission to use it
    public void check_flashlight_available() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 1);
        }

        boolean hasCameraFlash = this.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);
        if (!hasCameraFlash) {
            Toast.makeText(MainActivity.this, "No flash available on your device", Toast.LENGTH_SHORT).show();
            chb_flashlight.setEnabled(false);
        }
    }


    /// New thread-class to run computation in background
    class LoopTask extends AsyncTask {

        @Override
        protected Object doInBackground(Object[] objects) {

            ///iterating through input text
            for (Character c : et_input.getText().toString().toCharArray()) {

                String translated_label = "";
                if (spn_choose.getSelectedItem().toString().equals("Morse Code")) {
                    translated_label = translator.translate_letter_morse(c);
                } else {
                    translated_label = translator.translate_letter_tapcode(c);
                }

                Log.d("Actual Translation", translated_label);

                if (c.equals(' ')) {
                    tv_actual_letter.setText("(space)");
                } else {
                    tv_actual_letter.setText(c.toString());
                }

                /// iterating through coded label
                tv_actual_translation.setText(translated_label);
                for (Character cc : translated_label.toCharArray()) {
                    try {

                        if (isCancelled()) { /// used to destroy thread, when button is pressed again
                            return null;
                        }

                        Thread.sleep(time_unit); /// sleep between symbols

                        if (chb_flashlight.isChecked() && cc != '+' && cc != '/') {
                            flashlight_controller.enable_flashlight();
                        }

                        // calculating value of signa and so time of playing sound
                        if (chb_sound.isChecked()) {
                            switch (cc) {
                                case '*':
                                    SoundGenerator.toneGen(time_unit, 440);
                                    break;
                                case '-':
                                    SoundGenerator.toneGen(3 * time_unit, 440);
                                    break;
                                case '/':
                                    Thread.sleep(7 * time_unit);
                                    break;
                            }
                        } else {
                            switch (cc) {
                                case '*':
                                    Thread.sleep(time_unit);
                                    break;
                                case '-':
                                    Thread.sleep(3 * time_unit);
                                    break;
                                case '/':
                                    Thread.sleep(7 * time_unit);
                                    break;
                            }
                        }

                        if (chb_flashlight.isChecked()) {
                            flashlight_controller.disable_flashlight();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    Thread.sleep(3 * time_unit); /// sleep between letters
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            return null;
        }
    }

}
